import java.util.Scanner;
import java.util.Set;

public class Player {
    public Player(int num, char color) {
        number = num;
        this.color = color;
    }
    public int getNumber() {
        return number;
    }

    /**
     * Метод, позволяющий игроку выбрать следующий ход
     * @param field = поле
     * @param coordinates = возможные ходы
     * @return
     */
    public int[] makeDecision(Cell[][] field, Set<int[]> coordinates) {
        System.out.println("Enter your next move. Input example: '4;3'");
        boolean exception1 = true;
        int[] dec = new int[2];
        int i, j;
        while (exception1) {
            try {
                Scanner scanner = new Scanner(System.in);
                String inp = scanner.nextLine();
                if (inp.length() != 3) {
                    throw new RuntimeException();
                }
                String[] inp1 = inp.split(";");
                i = Integer.parseInt(inp1[0]);
                j = Integer.parseInt(inp1[1]);
                boolean wrongInput = true;
                for (int[] a : coordinates) {
                    if (i == a[0] && j == a[1]) {
                        wrongInput = false;
                    }
                }
                if (wrongInput) {
                    throw new RuntimeException();
                }
                dec[0] = i;
                dec[1] = j;
                exception1 = false;
            } catch (Exception e) {
                System.out.println("Wrong input, try again");
            }
        }
        return dec;
    }
    public char getColor() {
        return color;
    }
    private final int number;
    private final char color;
}
