import com.sun.source.tree.BreakTree;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.lang.String;

public class Main {
    public static void main(String[] args) {
        AtomicInteger max_score = new AtomicInteger(0);
        int operation = 0;
        while (operation != 4) {
            System.out.println("Your highest score: " + max_score);
            System.out.println("Choose game mode:");
            System.out.println("1) Easy AI mode");
            System.out.println("2) Advanced AI mode");
            System.out.println("3) PVP mode");
            System.out.println("4) Exit");
            boolean allRight = true;
            while (allRight) {
                try {
                    Scanner scanner = new Scanner(System.in);
                    operation = scanner.nextInt();
                    while (operation < 1 || operation > 4) {
                        System.out.println("Failed. Enter number between 1 and 4:");
                        operation = scanner.nextInt();
                    }
                    allRight = false;
                } catch (Exception e) {
                    System.out.println("Failed. Enter number between 1 and 4:");
                }
            }
            switch (operation) {
                case 1:
                    easyMode(max_score);
                    break;
                case 2:
                    advancedMode(max_score);
                    break;
                case 3:
                    playerMode(max_score);
                    break;
                case 4:
                    break;
            }
        }
    }

    /**
     * Легкий режим игры
     * @param highestScore = Лучший счет игрока
     */
    private static void easyMode(AtomicInteger highestScore) {
        AtomicInteger q = new AtomicInteger(0);
        Cell[][] field = createField();
        Player player = new Player(1, 'B');
        int move = 0;
        int p = 0;
        Cell[][] prevField = new Cell[8][8];
        StringBuilder possibleMoves;
        Set<int[]> movesCoordinates;
        Bot bot = new Bot('E', 'W');
        while (gameConditions(field)) {
            switch (move) {
                case 0: ;
                    ++move;
                    possibleMoves = checkAvailable(field, player.getColor());
                    movesCoordinates = stringToIntArray(possibleMoves, q);
                    drawField(field, movesCoordinates);
                    for (int[] a : movesCoordinates) {
                        a[0]++;
                        a[1]++;
                    }
                    if (p > 0) {
                        System.out.println("If you want to cancel your move, enter '1', if you want to continue, enter '0'");
                        boolean isBroken = true;
                        while (isBroken) {
                            try {
                                Scanner scanner = new Scanner(System.in);
                                int cancel = scanner.nextInt();
                                while (cancel < 0 || cancel > 1) {
                                    System.out.println("Wrong number");
                                    cancel = scanner.nextInt();
                                }
                                if (cancel == 1) {
                                    field = prevField;
                                    possibleMoves = checkAvailable(field, player.getColor());
                                    movesCoordinates = stringToIntArray(possibleMoves, q);
                                    drawField(field, movesCoordinates);
                                    for (int[] a : movesCoordinates) {
                                        a[0]++;
                                        a[1]++;
                                    }
                                }
                                isBroken = false;
                            } catch (Exception e) {
                                System.out.println("Wrong input, enter 1 or 0");
                            }
                        }
                    }
                    for (int i = 0; i <= 7; i++) {
                        for (int j = 0; j <= 7; j++) {
                            prevField[i][j] = new Cell(field[i][j].getColor());
                        }
                    }
                    p++;
                    if (q.get() == 0) {
                        System.out.println("Available moves:");
                        for (int[] mv : movesCoordinates) {
                            System.out.println(mv[0] + ";" + mv[1]);
                        }
                        int[] coord = player.makeDecision(field, movesCoordinates);
                        coord[0]--;
                        coord[1]--;
                        field = makeMove(coord[0], coord[1], field, player.getColor());
                    } else {
                        System.out.println("No available moves, opponents turn");
                    }
                    break;
                case 1:
                    --move;
                    possibleMoves = checkAvailable(field, bot.getColor());
                    movesCoordinates = stringToIntArray(possibleMoves, q);
                    for (int[] a : movesCoordinates) {
                        a[0]--;
                        a[1]--;
                    }
                    if (q.get() == 0) {
                        int[] coord = bot.makeDecision(field, movesCoordinates);
                        System.out.print("Opponent move: ");
                        System.out.println(coord[0] + 1 + ";" + (coord[1] + 1));
                        field = makeMove(coord[0], coord[1], field, bot.getColor());
                    } else {
                        System.out.println("No available moves, your turn");
                    }
                    break;
            }
        }
        drawFinalField(field);
        getHighestScore(highestScore, field, player.getColor());
        if (Win(field, player.getColor()) == player.getColor()) {
            System.out.println("You win!");
        } else if (Win(field, player.getColor()) == bot.getColor()) {
            System.out.println("You Lost!");
        } else if (Win(field, player.getColor()) == ' ') {
            System.out.println("Tie!");
        }
    }

    /**
     * Продвинутый режим игры
     * @param highestScore
     */
    private static void advancedMode(AtomicInteger highestScore) {
        AtomicInteger q = new AtomicInteger(0);
        Cell[][] field = createField();
        Player player = new Player(1, 'B');
        int move = 0;
        int p = 0;
        Cell[][] prevField = new Cell[8][8];
        StringBuilder possibleMoves;
        Set<int[]> movesCoordinates;
        Bot bot = new Bot('A', 'W');
        while (gameConditions(field)) {
            switch (move) {
                case 0: ;
                    ++move;
                    possibleMoves = checkAvailable(field, player.getColor());
                    movesCoordinates = stringToIntArray(possibleMoves, q);
                    drawField(field, movesCoordinates);
                    for (int[] a : movesCoordinates) {
                        a[0]++;
                        a[1]++;
                    }
                    if (p > 0) {
                        System.out.println("If you want to cancel your move, enter '1', if you want to continue, enter '0'");
                        boolean isBroken = true;
                        while (isBroken) {
                            try {
                                Scanner scanner = new Scanner(System.in);
                                int cancel = scanner.nextInt();
                                while (cancel < 0 || cancel > 1) {
                                    System.out.println("Wrong number");
                                    cancel = scanner.nextInt();
                                }
                                if (cancel == 1) {
                                    field = prevField;
                                    possibleMoves = checkAvailable(field, player.getColor());
                                    movesCoordinates = stringToIntArray(possibleMoves, q);
                                    drawField(field, movesCoordinates);
                                    for (int[] a : movesCoordinates) {
                                        a[0]++;
                                        a[1]++;
                                    }
                                }
                                isBroken = false;
                            } catch (Exception e) {
                                System.out.println("Wrong input, enter 1 or 0");
                            }
                        }
                    }
                    for (int i = 0; i <= 7; i++) {
                        for (int j = 0; j <= 7; j++) {
                            prevField[i][j] = new Cell(field[i][j].getColor());
                        }
                    }
                    p++;
                    if (q.get() == 0) {
                        System.out.println("Available moves:");
                        for (int[] mv : movesCoordinates) {
                            System.out.println(mv[0] + ";" + mv[1]);
                        }
                        int[] coord = player.makeDecision(field, movesCoordinates);
                        coord[0]--;
                        coord[1]--;
                        field = makeMove(coord[0], coord[1], field, player.getColor());
                    } else {
                        System.out.println("No available moves, opponents turn");
                    }
                    movesCoordinates.clear();
                    break;
                case 1:
                    --move;
                    possibleMoves = checkAvailable(field, bot.getColor());
                    movesCoordinates = stringToIntArray(possibleMoves, q);
                    if (q.get() == 0) {
                        for (int[] a : movesCoordinates) {
                            a[0]--;
                            a[1]--;
                        }
                        int[] coord = bot.makeDecision(field, movesCoordinates);
                        System.out.print("Opponent move: ");
                        System.out.println(coord[0] + 1 + ";" + (coord[1] + 1));
                        field = makeMove(coord[0], coord[1], field, bot.getColor());
                    } else {
                        System.out.println("No available moves, your turn");
                    }
                    break;
            }
        }
        drawFinalField(field);
        getHighestScore(highestScore, field, player.getColor());
        if (Win(field, player.getColor()) == player.getColor()) {
            System.out.println("You win!");
        } else if (Win(field, player.getColor()) == bot.getColor()) {
            System.out.println("You Lost!");
        } else if (Win(field, player.getColor()) == ' ') {
            System.out.println("Tie!");
        }
    }

    /**
     * Игрок против игрока
     * @param highestScore
     */
    private static void playerMode(AtomicInteger highestScore) {
        AtomicInteger q = new AtomicInteger(0);
        Cell[][] field = createField();
        Player player1 = new Player(1, 'B');
        int move = 0;
        StringBuilder possibleMoves;
        Set<int[]> movesCoordinates;
        Player player2 = new Player(2, 'W');
        while (gameConditions(field)) {
            switch (move) {
                case 0: ;
                    ++move;
                    possibleMoves = checkAvailable(field, player1.getColor());
                    movesCoordinates = stringToIntArray(possibleMoves, q);
                    drawField(field, movesCoordinates);
                    for (int[] a : movesCoordinates) {
                        a[0]++;
                        a[1]++;
                    }
                    if (q.get() == 0) {
                        System.out.println("Available moves for player #" + player1.getNumber() + ":");
                        for (int[] mv : movesCoordinates) {
                            System.out.println(mv[0] + ";" + mv[1]);
                        }
                        int[] coord = player1.makeDecision(field, movesCoordinates);
                        coord[0]--;
                        coord[1]--;
                        field = makeMove(coord[0], coord[1], field, player1.getColor());
                    } else {
                        System.out.println("No available moves, opponents turn");
                    }
                    getHighestScore(highestScore, field, player1.getColor());
                    break;
                case 1:
                    --move;
                    possibleMoves = checkAvailable(field, player2.getColor());
                    movesCoordinates = stringToIntArray(possibleMoves, q);
                    drawField(field, movesCoordinates);
                    for (int[] a : movesCoordinates) {
                        a[0]++;
                        a[1]++;
                    }
                    if (q.get() == 0) {
                        System.out.println("Available moves for player #" + player1.getNumber() + ":");
                        for (int[] mv : movesCoordinates) {
                            System.out.println(mv[0] + ";" + mv[1]);
                        }
                        int[] coord = player2.makeDecision(field, movesCoordinates);
                        coord[0]--;
                        coord[1]--;
                        field = makeMove(coord[0], coord[1], field, player2.getColor());
                    } else {
                        System.out.println("No available moves, opponents turn");
                    }
                    break;
            }
        }
        if (Win(field, player1.getColor()) == player1.getColor()) {
            System.out.println("Player #" + player1.getNumber() + " Win!");
        } else if (Win(field, player1.getColor()) == player2.getColor()) {
            System.out.println("Player #" + player2.getNumber() + " Win!");
        } else if (Win(field, player1.getColor()) == ' ') {
            System.out.println("Tie!");
        }
    }

    /**
     * Метод, генерирующий начальное поле для игры
     * @return
     */
    static Cell[][] createField() {
        Cell[][] field = new Cell[8][8];
        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                field[i][j] = new Cell();
            }
        }
        field[3][3].swapColor('W');
        field[3][4].swapColor('B');
        field[4][3].swapColor('B');
        field[4][4].swapColor('W');
        return field;
    }

    /**
     * Метод, рисующий итоговое поле игры
     * @param field = поле
     */
    static void drawFinalField(Cell[][] field) {
        System.out.print(" ||" + " ");
        for (int i = 0; i < 8; ++i) {
            System.out.print(i+1 + " || ");
        }
        System.out.println();
        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                if (j == 0) {
                    System.out.print(i+1 + "|| " + field[i][j].getColor() + " |");
                } else {
                    System.out.print("| " + field[i][j].getColor() + " |");
                }
            }
            System.out.print("|");
            System.out.println();
        }
        System.out.println("-------------------------------------------");
    }

    /**
     * Метод, рисующий поле для игры с возможными ходами
     * @param field = поле
     * @param coordinates = возможные ходы
     */
    static void drawField(Cell[][] field, Set<int[]> coordinates) {
        for (int[] a : coordinates) {
            a[0]--;
            a[1]--;
        }
        System.out.print(" |" + " ");
        for (int i = 0; i < 8; ++i) {
            System.out.print(" " + (i+1) + "  | ");
        }
        System.out.println();
        System.out.println("——————————————————————————————————————————————————");
        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                if (j == 0) {
                    if (field[i][j].getColor() == 'W') {
                        System.out.print(i + 1 + "| " + "⚪" + " |");
                    } else if (field[i][j].getColor() == 'B'){
                        System.out.print(i + 1 + "| " + "⚫" + " |");
                    } else {
                        boolean canMove = false;
                        for (int[] a : coordinates) {
                            if (a[0] == i && a[1] == j) {
                                canMove = true;
                            }
                        }
                        if (canMove) {
                            System.out.print(i + 1 + "| " + " ◌ " + " |");
                        } else {
                            System.out.print(i + 1 + "| " + "   " + " |");
                        }
                    }
                } else {
                    if (field[i][j].getColor() == 'W') {
                        System.out.print(" ⚪ " + " |");
                    } else if (field[i][j].getColor() == 'B'){
                        System.out.print(" ⚫ " + " |");
                    } else {
                        boolean canMove = false;
                        for (int[] a : coordinates) {
                            if (a[0] == i && a[1] == j) {
                                canMove = true;
                            }
                        }
                        if (canMove) {
                            System.out.print("  ◌ " + " |");
                        } else {
                            System.out.print("    " + " |");
                        }
                    }
                }
            }
            System.out.println();
            System.out.println("——————————————————————————————————————————————————");
        }
    }

    /**
     * Проверка выполнены ли условия конца игры
     * @param field
     * @return
     */
    static boolean gameConditions(Cell[][] field) {
        return (notFull(field) && twoColors(field));
    }

    /**
     * Заполнено ли поле
     * @param field
     * @return
     */
    static boolean notFull(Cell[][] field) {
        int amountOfCells = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (field[i][j].getColor() != ' ') {
                    amountOfCells++;
                }
            }
        }
        if (amountOfCells == 64) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Есть ли на поле оба цвета
     * @param field
     * @return
     */
    static boolean twoColors(Cell[][] field) {
        int white = 0;
        int black = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (field[i][j].getColor() == 'B') {
                    black++;
                }
                if (field[i][j].getColor() == 'W') {
                    white++;
                }
            }
        }
        if (white == 0 || black == 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Проверка возможных ходов
     * @param field = поле
     * @param color = для какого цвета ищем ходы
     * @return
     */
    static StringBuilder checkAvailable(Cell[][] field, char color) {
        StringBuilder v = new StringBuilder();
        int p = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (field[i][j].getColor() == color) {
                    v.append(transit(field, i, j, color));
                }
            }
        }
        return v;
    }

    /**
     * Переходник для проверки всех направлений
     * @param field = поле
     * @param i = i-тая координата
     * @param j = j-тая координата
     * @param color = цвет
     * @return
     */
    static StringBuilder transit(Cell[][] field, int i, int j, char color) {
        StringBuilder v = new StringBuilder();
        v.append(Up(field, i, j, color));
        v.append(Down(field, i, j, color));
        v.append(Left(field, i, j, color));
        v.append(Right(field, i, j, color));
        v.append(UpLeft(field, i, j, color));
        v.append(UpRight(field, i, j, color));
        v.append(DownLeft(field, i, j, color));
        v.append(DownRight(field, i, j, color));
        return v;
    }
    static StringBuilder Up(Cell[][] field, int i, int j, char color) {
        StringBuilder v = new StringBuilder();
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        --i;
        while (i >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            --i;
        }
        return new StringBuilder();
    }
    static StringBuilder Down(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        ++i;
        while (i <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            ++i;
        }
        return new StringBuilder();
    }
    static StringBuilder Left(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        --j;
        while (j >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            --j;
        }
        return new StringBuilder();
    }
    static StringBuilder Right(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        ++j;
        while (j <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            ++j;
        }
        return new StringBuilder();
    }
    static StringBuilder UpRight(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        ++j;
        --i;
        while (j <= 7 && i >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            ++j;
            --i;
        }
        return new StringBuilder();
    }
    static StringBuilder UpLeft(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        --j;
        --i;
        while (j >= 0 && i >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount != 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            --j;
            --i;
        }
        return new StringBuilder();
    }
    static StringBuilder DownRight(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        ++j;
        ++i;
        while (j <= 7 && i <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            ++j;
            ++i;
        }
        return new StringBuilder();
    }
    static StringBuilder DownLeft(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        --j;
        ++i;
        while (j >= 0 && i <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i][j].getColor() == color) {
                return new StringBuilder();
            }
            if (field[i][j].getColor() == ' ') {
                if (colorCount > 0) {
                    j++;
                    return new StringBuilder((i + 1 + ";" + j + '\n'));
                } else {
                    return new StringBuilder();
                }
            }
            --j;
            ++i;
        }
        return new StringBuilder();
    }

    /**
     * Полученные ходы в виде текста переводим в Сет от массива интов
     * @param text = ходы в виде текста
     * @param q = Проверочная переменная на случай ошибки (= нет доступных ходов)
     * @return
     */
    static Set<int[]> stringToIntArray(StringBuilder text, AtomicInteger q) {
        String textS = text.toString();
        String[] lines = textS.split("\n");
        Set<int[]> coordinates = new HashSet<>();
        try {
            for (String line : lines) {
                String[] numbers = line.split(";");
                int[] coord = new int[2];
                coord[0] = Integer.parseInt(numbers[0]);
                coord[1] = Integer.parseInt(numbers[1]);
                boolean checker = false;
                for (int[] a : coordinates) {
                    if (coord[0] == a[0] && coord[1] == a[1]) {
                        checker = true;
                    }
                }
                if (!checker) {
                    coordinates.add(coord);
                }
            }
        } catch (Exception e) {
            q.set(1);
        }
        return coordinates;
    }

    /**
     * Метод, проверяющий побит ли рекорд игрока
     * @param highestScore
     * @param field
     * @param color
     */
    static void getHighestScore(AtomicInteger highestScore, Cell[][] field, char color) {
        int curScore = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (field[i][j].getColor() == color) {
                    curScore++;
                }
            }
        }
        if (curScore > highestScore.get()) {
            highestScore.set(curScore);
        }
    }

    /**
     * Метод, выполняющий ход
     * @param i
     * @param j
     * @param field
     * @param color
     * @return
     */
    static Cell[][] makeMove(int i, int j, Cell[][] field, char color) {
        field[i][j].swapColor(color);
        field = changeUp(field, i, j, color);
        field = changeDown(field, i, j, color);
        field = changeLeft(field, i, j, color);
        field = changeRight(field, i, j, color);
        field = changeUpRight(field, i, j, color);
        field = changeUpLeft(field, i, j, color);
        field = changeDownRight(field, i, j, color);
        field = changeDownLeft(field, i, j, color);
        return field;
    }

    /**
     * Метод меняющий, при необходимости, все подходящие верхние координаты
     * @param field
     * @param i
     * @param j
     * @param color
     * @return
     */
    static Cell[][] changeUp(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        --i1;
        while (i1 >= 0) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                i1 = -1;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            --i1;
        }
        --i;
        while (i >= 0 &&field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            --i;
        }
        return field;
    }
    static Cell[][] changeDown(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        ++i1;
        while (i1 <= 7) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                i1 = 8;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            ++i1;
        }
        ++i;
        while (i <= 7 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            ++i;
        }
        return field;
    }
    static Cell[][] changeLeft(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        --j1;
        while (j1 >= 0) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                j1 = -1;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            --j1;
        }
        --j;
        while (j >= 0 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            --j;
        }
        return field;
    }
    static Cell[][] changeRight(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        ++j1;
        while (j1 <= 7) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                j1 = 8;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            ++j1;
        }
        ++j;
        while (j <= 7 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            ++j;
        }
        return field;
    }
    static Cell[][] changeUpRight(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        ++j1;
        --i1;
        while (j1 <= 7 && i1 >= 0) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                j1 = 8;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            ++j1;
            --i1;
        }
        ++j;
        --i;
        while (j <= 7 && i >= 0 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            ++j;
            --i;
        }
        return field;
    }
    static Cell[][] changeUpLeft(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        --j1;
        --i1;
        while (j1 >= 0 && i1 >= 0) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                j1 = -1;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            --j1;
            --i1;
        }
        --j;
        --i;
        while (j >= 0 && i >= 0 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            --j;
            --i;
        }
        return field;
    }
    static Cell[][] changeDownRight(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        ++j1;
        ++i1;
        while (j1 <= 7 && i1 <= 7) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                j1 = 8;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            ++j1;
            ++i1;
        }
        ++j;
        ++i;
        while (j <= 7 && i <= 7 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            ++j;
            ++i;
        }
        return field;
    }
    static Cell[][] changeDownLeft(Cell[][] field, int i, int j, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int colorCount = 0;
        boolean isChanging = false;
        int i1 = i;
        int j1 = j;
        --j1;
        ++i1;
        while (j1 >= 0 && i1 <= 7) {
            if (field[i1][j1].getColor() == oppositeColor) {
                colorCount++;
            }
            if (field[i1][j1].getColor() == color) {
                if (colorCount == 0) {
                    return field;
                }
                j1 = -1;
            } else if (field[i1][j1].getColor() == ' ') {
                return field;
            }
            --j1;
            ++i1;
        }
        --j;
        ++i;
        while (j >= 0 && i <= 7 && field[i][j].getColor() != color) {
            field[i][j].swapColor(color);
            --j;
            ++i;
        }
        return field;
    }

    /**
     * Метод, считающий результат игры
     * @param field
     * @param color
     * @return
     */
    static char Win(Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int opponent = 0;
        int player = 0;
        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                if (field[i][j].getColor() == color) {
                    player++;
                } else if (field[i][j].getColor() == oppositeColor) {
                    opponent++;
                }
            }
        }
        System.out.println(color + ": " + player);
        System.out.println(oppositeColor + ": " + opponent);
        if (player > opponent) {
            return color;
        } else if (opponent > player) {
            return oppositeColor;
        } else {
            return ' ';
        }
    }
}