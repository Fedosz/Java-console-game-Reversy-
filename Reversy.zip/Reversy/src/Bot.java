import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public class Bot {
    public Bot(char difficulty, char clr) {
        this.difficulty = difficulty;
        color = clr;
    }
    public char getDifficulty() {
        return difficulty;
    }
    public char getColor() {
        return color;
    }

    /**
     * Метод, отправляющий нас к нужному алгоритму для решения бота
     * @param field
     * @param coordinates
     * @return
     */
    public int[] makeDecision(Cell[][] field, Set<int[]> coordinates) {
        if (difficulty == 'E') {
            return makeEasyDecision(field, coordinates, this.getColor());
        }
        if (difficulty == 'A') {
            return makeAdvancedDecision(field, coordinates);
        }
        return null;
    }

    /**
     * Решение в случае легкого алгоритма
     * @param field
     * @param coordinates
     * @param color
     * @return
     */
    private int[] makeEasyDecision(Cell[][] field, Set<int[]> coordinates, char color) {
        double maxValue = 0;
        int[] decision = new int[2];
        for (int[] cd : coordinates) {
            if (easyValue(cd, field, color) > maxValue) {
                maxValue = easyValue(cd, field, color);
                decision = cd;
            }
        }
        return decision;
    }

    /**
     * Решение в случае продвинутого алгоритма
     * @param field
     * @param coordinates
     * @return
     */
    private int[] makeAdvancedDecision(Cell[][] field, Set<int[]> coordinates) {
        char oppositeColor = ' ';
        if (this.color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        StringBuilder possibleMoves;
        Set<int[]> movesCoordinates;
        double maxValue = -50;
        AtomicInteger q = new AtomicInteger(0);
        int[] decision = new int[2];
        Cell[][] newField = new Cell[8][8];
        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                newField[i][j] = new Cell(field[i][j].getColor());
            }
        }
        for (int[] cd : coordinates) {
            char prevColor = field[cd[0]][cd[1]].getColor();
            newField[cd[0]][cd[1]].swapColor(color);
            possibleMoves = Main.checkAvailable(newField, oppositeColor);
            movesCoordinates = Main.stringToIntArray(possibleMoves, q);
            if (q.get() == 0) {
                for (int[] a : movesCoordinates) {
                    a[0]--;
                    a[1]--;
                }
                if (easyValue(cd, field, this.color) - easyValue(makeEasyDecision(newField, movesCoordinates, oppositeColor), newField, oppositeColor) > maxValue) {
                    maxValue = easyValue(cd, field, this.color) - easyValue(makeEasyDecision(newField, movesCoordinates, oppositeColor), newField, oppositeColor);
                    decision = cd;
                }
            } else {
                if (easyValue(cd, field, this.color) > maxValue) {
                    maxValue = easyValue(cd, field, this.color);
                    decision = cd;
                }
            }
            newField[cd[0]][cd[1]].swapColor(prevColor);
        }
        return decision;
    }

    /**
     * Ценность хода
     * @param cd = координаты хода
     * @param field
     * @param color
     * @return
     */
    private double easyValue(int[] cd, Cell[][] field, char color) {
        double res = 0;
        if (cd[0] % 7 == 0 && cd[1] % 7 == 0) {
            res += 0.8;
        } else if (cd[0] % 7 == 0 || cd[1] % 7 == 0) {
            res += 0.4;
        }
        res += Up(cd, field, color);
        res += Down(cd, field, color);
        res += Left(cd, field, color);
        res += Right(cd, field, color);
        res += UpRight(cd, field, color);
        res += UpLeft(cd, field, color);
        res += DownRight(cd, field, color);
        res += DownLeft(cd, field, color);
        return res;
    }

    /**
     * Проверка ценности верхних замен (при необходимости)
     * @param cd
     * @param field
     * @param color
     * @return
     */
    double Up(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        --i;
        while (i >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            --i;
        }
        return 0;
    }
    double Down(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        ++i;
        while (i <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            ++i;
        }
        return 0;
    }
    double Left(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        --j;
        while (j >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            --j;
        }
        return 0;
    }
    double Right(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        ++j;
        while (j <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            ++j;
        }
        return 0;
    }
    double UpRight(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        ++j;
        --i;
        while (j <= 7 && i >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            ++j;
            --i;
        }
        return 0;
    }
    double UpLeft(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        --j;
        --i;
        while (j >= 0 && i >= 0) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            --j;
            --i;
        }
        return 0;
    }
    double DownRight(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        ++j;
        ++i;
        while (j <= 7 && i <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            ++j;
            ++i;
        }
        return 0;
    }
    double DownLeft(int[] cd, Cell[][] field, char color) {
        char oppositeColor;
        if (color == 'W') {
            oppositeColor = 'B';
        } else {
            oppositeColor = 'W';
        }
        int otherColor = 0;
        int i = cd[0];
        int j = cd[1];
        --j;
        ++i;
        while (j >= 0 && i <= 7) {
            if (field[i][j].getColor() == oppositeColor) {
                if (i % 7 == 0 || j % 7 == 0) {
                    otherColor++;
                }
                otherColor++;
            }
            if (field[i][j].getColor() == color) {
                return otherColor;
            } else if (field[i][j].getColor() == ' ') {
                return 0;
            }
            --j;
            ++i;
        }
        return 0;
    }

    private final char difficulty;
    private final char color;
}
