public class Cell {
    public Cell() {
        color = ' ';
    }
    public Cell(char color) {
        this.color = color;
    }
    public char getColor() {
        return color;
    }
    public void swapColor(char color) {
        this.color = color;
    }
    private char color;
}
